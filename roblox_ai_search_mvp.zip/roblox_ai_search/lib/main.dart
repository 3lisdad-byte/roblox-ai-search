import 'package:flutter/material.dart';

void main() => runApp(const RobloxAiApp());

class RobloxAiApp extends StatefulWidget {
  const RobloxAiApp({super.key});
  @override
  State<RobloxAiApp> createState() => _RobloxAiAppState();
}

class _RobloxAiAppState extends State<RobloxAiApp> {
  bool arabic = true;
  bool dark = true;

  void setLanguage(bool value) => setState(() => arabic = value);
  void setTheme(bool value) => setState(() => dark = value);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Roblox AI Search',
      theme: AppTheme.dark,
      home: AppShell(
        arabic: arabic,
        dark: dark,
        onLanguageChanged: setLanguage,
        onThemeChanged: setTheme,
      ),
    );
  }
}

class AppTheme {
  static ThemeData get dark => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xFF080A10),
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color(0xFF7C5CFF),
      brightness: Brightness.dark,
    ),
    fontFamily: 'sans',
    useMaterial3: true,
  );
}

class Game {
  final String name, genre, description, icon;
  final double rating, match;
  final int players;
  Game(this.name, this.genre, this.description, this.icon, this.rating, this.match, this.players);
}

final games = <Game>[
  Game('DOORS', 'Horror • Multiplayer', 'Survive a mysterious hotel, solve puzzles and escape.', '🚪', 4.8, 94, 86000),
  Game('The Mimic', 'Horror • Story', 'A dark story-driven horror adventure with friends.', '👹', 4.6, 89, 32000),
  Game('Brookhaven RP', 'Roleplay • Social', 'Hang out, roleplay and explore a lively town.', '🏡', 4.7, 87, 79000),
  Game('Blox Fruits', 'Adventure • Fighting', 'Explore islands, fight enemies and discover powers.', '⚔️', 4.7, 85, 15000),
  Game('Pet Simulator', 'Simulator • Casual', 'Collect pets, unlock worlds and build your collection.', '🐾', 4.5, 82, 12000),
];

class AppShell extends StatefulWidget {
  final bool arabic, dark;
  final ValueChanged<bool> onLanguageChanged, onThemeChanged;
  const AppShell({
    super.key,
    required this.arabic,
    required this.dark,
    required this.onLanguageChanged,
    required this.onThemeChanged,
  });

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int tab = 0;
  final favorites = <String>{};
  final history = <String>[];

  String t(String ar, String en) => widget.arabic ? ar : en;

  void openSearch() => Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => AiSearchPage(
        arabic: widget.arabic,
        onSearch: (q) {
          if (q.trim().isNotEmpty && !history.contains(q.trim())) {
            setState(() => history.insert(0, q.trim()));
          }
        },
        onResults: (q) => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ResultsPage(
              arabic: widget.arabic,
              query: q,
              favorites: favorites,
              onFavorite: (name) => setState(() {
                favorites.contains(name) ? favorites.remove(name) : favorites.add(name);
              }),
            ),
          ),
        ),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(arabic: widget.arabic, onSearch: openSearch),
      SearchLandingPage(arabic: widget.arabic, onSearch: openSearch),
      FavoritesPage(arabic: widget.arabic, favorites: favorites),
      SettingsPage(
        arabic: widget.arabic,
        dark: widget.dark,
        onLanguageChanged: widget.onLanguageChanged,
        onThemeChanged: widget.onThemeChanged,
        history: history,
        favorites: favorites,
      ),
    ];
    return Directionality(
      textDirection: widget.arabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        body: SafeArea(child: pages[tab]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          backgroundColor: const Color(0xFF10131B),
          indicatorColor: const Color(0xFF3B2A82),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: t('الرئيسية','Home')),
            NavigationDestination(icon: const Icon(Icons.search), label: t('البحث','Search')),
            NavigationDestination(icon: const Icon(Icons.favorite_border), selectedIcon: const Icon(Icons.favorite), label: t('المفضلة','Favorites')),
            NavigationDestination(icon: const Icon(Icons.settings_outlined), selectedIcon: const Icon(Icons.settings), label: t('الإعدادات','Settings')),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final bool arabic;
  final VoidCallback onSearch;
  const HomePage({super.key, required this.arabic, required this.onSearch});

  String t(String ar, String en) => arabic ? ar : en;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 42, height: 42, decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(13),
            gradient: const LinearGradient(colors: [Color(0xFF7C5CFF), Color(0xFF00D9FF)]),
          ), child: const Icon(Icons.smart_toy_rounded, color: Colors.white)),
          const SizedBox(width: 10),
          const Text('Roblox AI', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const Spacer(),
          IconButton(onPressed: () {}, icon: const Icon(Icons.language)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.settings_outlined)),
        ]),
        const SizedBox(height: 24),
        Text(t('مرحباً يا لاعب! 👋','Hey, Gamer! 👋'), style: const TextStyle(fontSize: 16, color: Color(0xFFB7B9C5))),
        const SizedBox(height: 4),
        Text(t('ماذا تريد أن تلعب اليوم؟','What do you want to play today?'), style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
        const SizedBox(height: 18),
        GestureDetector(
          onTap: onSearch,
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(colors: [Color(0xFF5E35E8), Color(0xFF008DFF)]),
              boxShadow: const [BoxShadow(color: Color(0x553B1DFF), blurRadius: 24, offset: Offset(0, 10))],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.auto_awesome, size: 22),
                const SizedBox(width: 8),
                Text(t('اسأل الذكاء الاصطناعي','Ask AI'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                const Spacer(),
                const CircleAvatar(radius: 16, child: Icon(Icons.arrow_forward, size: 17)),
              ]),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                decoration: BoxDecoration(color: Colors.black.withOpacity(.22), borderRadius: BorderRadius.circular(14)),
                child: Row(children: [
                  Expanded(child: Text(t('اكتب وصف اللعبة التي تريدها...','Describe the game you want...'), style: const TextStyle(color: Colors.white70))),
                  const Icon(Icons.mic_none),
                ]),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 26),
        SectionTitle(t('الأكثر شعبية','Popular'), t('المزيد','More')),
        const SizedBox(height: 12),
        SizedBox(height: 154, child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: 4,
          separatorBuilder: (_,__) => const SizedBox(width: 12),
          itemBuilder: (_, i) => MiniGameCard(game: games[i]),
        )),
        const SizedBox(height: 26),
        Text(t('التصنيفات','Categories'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        Wrap(spacing: 10, runSpacing: 10, children: [
          '👻 ${t("رعب","Horror")}', '✨ ${t("أنمي","Anime")}', '🏎️ ${t("سباق","Racing")}',
          '💰 ${t("تايكون","Tycoon")}', '🎭 ${t("تمثيل","Roleplay")}', '🗺️ ${t("مغامرة","Adventure")}',
        ].map((x) => Chip(label: Text(x))).toList()),
      ]),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title, action;
  const SectionTitle(this.title, this.action, {super.key});
  @override
  Widget build(BuildContext context) => Row(children: [
    Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
    const Spacer(),
    Text(action, style: const TextStyle(color: Color(0xFF9C82FF), fontWeight: FontWeight.w700)),
  ]);
}

class MiniGameCard extends StatelessWidget {
  final Game game;
  const MiniGameCard({super.key, required this.game});
  @override
  Widget build(BuildContext context) => Container(
    width: 154,
    padding: const EdgeInsets.all(9),
    decoration: BoxDecoration(color: const Color(0xFF131722), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF262B3A))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Container(
        width: double.infinity,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), gradient: const LinearGradient(colors: [Color(0xFF271A59), Color(0xFF102E55)])),
        child: Center(child: Text(game.icon, style: const TextStyle(fontSize: 42))),
      )),
      const SizedBox(height: 7),
      Text(game.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
      Text('⭐ ${game.rating}  •  ${formatPlayers(game.players)}', style: const TextStyle(fontSize: 11, color: Colors.white60)),
    ]),
  );
}

String formatPlayers(int n) => n >= 1000 ? '${(n/1000).toStringAsFixed(n >= 10000 ? 0 : 1)}K' : '$n';

class SearchLandingPage extends StatelessWidget {
  final bool arabic;
  final VoidCallback onSearch;
  const SearchLandingPage({super.key, required this.arabic, required this.onSearch});
  String t(String ar, String en) => arabic ? ar : en;
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.auto_awesome, size: 72, color: Color(0xFF00D9FF)),
      const SizedBox(height: 16),
      Text(t('البحث بالذكاء الاصطناعي','AI Search'), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Text(t('اوصف اللعبة اللي ببالك وخلي الذكاء الاصطناعي يختار لك أفضل النتائج.','Describe the game you have in mind and let AI find the best matches.'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
      const SizedBox(height: 28),
      FilledButton.icon(onPressed: onSearch, icon: const Icon(Icons.search), label: Text(t('ابدأ البحث','Start searching')), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54))),
    ]),
  );
}

class AiSearchPage extends StatefulWidget {
  final bool arabic;
  final ValueChanged<String> onSearch;
  final ValueChanged<String> onResults;
  const AiSearchPage({super.key, required this.arabic, required this.onSearch, required this.onResults});
  @override State<AiSearchPage> createState() => _AiSearchPageState();
}
class _AiSearchPageState extends State<AiSearchPage> {
  final controller = TextEditingController();
  bool busy = false;
  String t(String ar, String en) => widget.arabic ? ar : en;
  Future<void> submit() async {
    if (controller.text.trim().isEmpty) return;
    widget.onSearch(controller.text);
    setState(() => busy = true);
    await Future.delayed(const Duration(milliseconds: 1100));
    if (!mounted) return;
    setState(() => busy = false);
    widget.onResults(controller.text);
  }
  @override
  Widget build(BuildContext context) {
    if (busy) return Directionality(textDirection: widget.arabic ? TextDirection.rtl : TextDirection.ltr, child: const ProcessingPage());
    return Scaffold(
      appBar: AppBar(title: Text(t('البحث بالذكاء الاصطناعي','AI Search'))),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const SizedBox(height: 10),
        const Icon(Icons.smart_toy_rounded, size: 74, color: Color(0xFF7C5CFF)),
        const SizedBox(height: 12),
        Text(t('أخبرني بما تريد أن تلعب','Tell me what you want to play'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
        const SizedBox(height: 20),
        TextField(
          controller: controller, maxLines: 5, maxLength: 500,
          decoration: InputDecoration(
            hintText: t('مثلاً: أريد لعبة رعب ألعبها ويا أصدقائي وتكون سهلة','Example: I want an easy horror game to play with friends'),
            filled: true, fillColor: const Color(0xFF121620),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            suffixIcon: const Icon(Icons.mic_none),
          ),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: submit, icon: const Icon(Icons.auto_awesome), label: Text(t('ابحث عن ألعاب','Find Games')), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54))),
        const SizedBox(height: 26),
        Text(t('اقتراحات سريعة','Quick Suggestions'), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: ['Horror','Multiplayer','Funny','Adventure','Anime','Tycoon'].map((x) => ActionChip(label: Text(x), onPressed: () => controller.text = x)).toList()),
      ]),
    );
  }
}

class ProcessingPage extends StatelessWidget {
  const ProcessingPage({super.key});
  @override
  Widget build(BuildContext context) {
    final ar = Directionality.of(context) == TextDirection.rtl;
    String t(String a, String e) => ar ? a : e;
    return Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.smart_toy_rounded, size: 88, color: Color(0xFF00D9FF)),
      const SizedBox(height: 20),
      Text(t('الذكاء الاصطناعي يفكر...','AI is thinking...'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      const SizedBox(height: 26),
      for (final s in [
        ['✓', t('فهم طلبك','Understanding your request')],
        ['✓', t('تحليل التفضيلات','Analyzing preferences')],
        ['✓', t('البحث عن ألعاب Roblox','Searching Roblox games')],
        ['✓', t('ترتيب أفضل النتائج','Ranking the best matches')],
      ]) ListTile(leading: CircleAvatar(radius: 13, backgroundColor: const Color(0xFF17B978), child: Text(s[0])), title: Text(s[1])),
      const SizedBox(height: 18),
      Text(t('قد يستغرق هذا بضع ثوانٍ...','This might take a few seconds...'), style: const TextStyle(color: Colors.white54)),
    ])));
  }
}

class ResultsPage extends StatelessWidget {
  final bool arabic;
  final String query;
  final Set<String> favorites;
  final ValueChanged<String> onFavorite;
  const ResultsPage({super.key, required this.arabic, required this.query, required this.favorites, required this.onFavorite});
  String t(String ar, String en) => arabic ? ar : en;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(t('نتائج البحث','Search Results')),
      actions: [IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FiltersPage(arabic: arabic))), icon: const Icon(Icons.tune))],
    ),
    body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
      Text(t('${games.length} ألعاب مناسبة','${games.length} matching games'), style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.white70)),
      const SizedBox(height: 12),
      ...games.map((g) => GameResultCard(game: g, arabic: arabic, favorite: favorites.contains(g.name), onFavorite: () => onFavorite(g.name))),
    ]),
  );
}

class GameResultCard extends StatelessWidget {
  final Game game; final bool arabic, favorite; final VoidCallback onFavorite;
  const GameResultCard({super.key, required this.game, required this.arabic, required this.favorite, required this.onFavorite});
  String t(String ar, String en) => arabic ? ar : en;
  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF121722), margin: const EdgeInsets.only(bottom: 14),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFF242A3A))),
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GameDetailsPage(game: game, arabic: arabic, favorite: favorite, onFavorite: onFavorite))),
      child: Padding(padding: const EdgeInsets.all(11), child: Column(children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 92, height: 92, decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: const LinearGradient(colors: [Color(0xFF30205F), Color(0xFF123A61)])), child: Center(child: Text(game.icon, style: const TextStyle(fontSize: 44)))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: Text(game.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))), IconButton(onPressed: onFavorite, icon: Icon(favorite ? Icons.favorite : Icons.favorite_border, color: favorite ? Colors.pinkAccent : null))]),
            Text(game.genre, style: const TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 7),
            Text('⭐ ${game.rating}   👥 ${formatPlayers(game.players)}', style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: const Color(0x2222C55E), borderRadius: BorderRadius.circular(8)), child: Text('${game.match}% ${t("تطابق","Match")}', style: const TextStyle(color: Color(0xFF4ADE80), fontWeight: FontWeight.w800, fontSize: 12))),
          ])),
        ]),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.open_in_new, size: 17), label: Text(t('فتح في Roblox','Open in Roblox')))),
      ])),
    ),
  );
}

class FiltersPage extends StatefulWidget {
  final bool arabic;
  const FiltersPage({super.key, required this.arabic});
  @override State<FiltersPage> createState() => _FiltersPageState();
}
class _FiltersPageState extends State<FiltersPage> {
  String genre='Horror', players='Multiplayer', difficulty='Medium', sort='AI Match';
  String t(String ar,String en)=>widget.arabic?ar:en;
  Widget choices(String title, List<String> values, String selected, ValueChanged<String> change) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), const SizedBox(height: 9),
    Wrap(spacing: 8, runSpacing: 8, children: values.map((v)=>ChoiceChip(label: Text(v), selected:selected==v, onSelected:(_)=>change(v))).toList()), const SizedBox(height: 20)
  ]);
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(title: Text(t('الفلاتر','Filters'))),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      choices(t('النوع','Genre'), ['Horror','Anime','Racing','Tycoon','Roleplay','Adventure'], genre,(v)=>setState(()=>genre=v)),
      choices(t('عدد اللاعبين','Players'), ['Solo','2 Players','Multiplayer'], players,(v)=>setState(()=>players=v)),
      choices(t('الصعوبة','Difficulty'), ['Easy','Medium','Hard'], difficulty,(v)=>setState(()=>difficulty=v)),
      choices(t('الترتيب حسب','Sort by'), ['AI Match','Popularity','Rating'], sort,(v)=>setState(()=>sort=v)),
      FilledButton(onPressed: ()=>Navigator.pop(context), child: Text(t('تطبيق الفلاتر','Apply Filters'))),
    ]),
  );
}

class GameDetailsPage extends StatelessWidget {
  final Game game; final bool arabic, favorite; final VoidCallback onFavorite;
  const GameDetailsPage({super.key, required this.game, required this.arabic, required this.favorite, required this.onFavorite});
  String t(String ar,String en)=>arabic?ar:en;
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(actions:[IconButton(onPressed:onFavorite,icon:Icon(favorite?Icons.favorite:Icons.favorite_border,color:favorite?Colors.pinkAccent:null))]),
    body: ListView(padding: const EdgeInsets.fromLTRB(18,0,18,28), children:[
      Container(height:220, decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF311B66),Color(0xFF123E62)])),child:Center(child:Text(game.icon,style:const TextStyle(fontSize:90)))),
      const SizedBox(height:18),
      Text(game.name,style:const TextStyle(fontSize:29,fontWeight:FontWeight.w900)),
      Text('⭐ ${game.rating}   •   👥 ${formatPlayers(game.players)}',style:const TextStyle(color:Colors.white70)),
      const SizedBox(height:12),
      Wrap(spacing:8,children:game.genre.split(' • ').map((x)=>Chip(label:Text(x))).toList()),
      const SizedBox(height:12),
      Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:const Color(0xFF101D2A),borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0xFF00A9FF))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('🤖 ${t('لماذا اخترناها لك؟','Why you will like it')}',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:16)),
        const SizedBox(height:8),
        Text(t('تطابق هذه اللعبة طلبك بفضل نوعها، أسلوب اللعب الجماعي وتقييمها الجيد.','This game matches your request because of its genre, multiplayer style and strong community rating.')),
      ])),
      const SizedBox(height:20),
      Text(t('عن اللعبة','About'),style:const TextStyle(fontSize:20,fontWeight:FontWeight.w800)),
      const SizedBox(height:8), Text(game.description,style:const TextStyle(color:Colors.white70,height:1.5)),
      const SizedBox(height:24),
      FilledButton.icon(onPressed:(){},icon:const Icon(Icons.sports_esports),label:Text(t('فتح في Roblox','Open in Roblox')),style:FilledButton.styleFrom(minimumSize:const Size.fromHeight(55))),
    ]),
  );
}

class FavoritesPage extends StatelessWidget {
  final bool arabic; final Set<String> favorites;
  const FavoritesPage({super.key, required this.arabic, required this.favorites});
  String t(String a,String e)=>arabic?a:e;
  @override Widget build(BuildContext context){
    final saved=games.where((g)=>favorites.contains(g.name)).toList();
    return Scaffold(appBar:AppBar(title:Text(t('المفضلة','Favorites'))),body:saved.isEmpty
      ? Center(child:Padding(padding:const EdgeInsets.all(30),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('❤️',style:TextStyle(fontSize:55)),const SizedBox(height:15),Text(t('لا توجد ألعاب محفوظة بعد','No favorites yet'),style:const TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:8),Text(t('احفظ الألعاب التي تريد لعبها لاحقاً.','Save games you want to play later.'),textAlign:TextAlign.center,style:const TextStyle(color:Colors.white60))])))
      : ListView(padding:const EdgeInsets.all(16),children:saved.map((g)=>ListTile(leading:CircleAvatar(child:Text(g.icon)),title:Text(g.name),subtitle:Text('⭐ ${g.rating}  •  ${g.genre}')).toList()));
  }
}

class SettingsPage extends StatelessWidget {
  final bool arabic,dark; final ValueChanged<bool> onLanguageChanged,onThemeChanged; final List<String> history; final Set<String> favorites;
  const SettingsPage({super.key,required this.arabic,required this.dark,required this.onLanguageChanged,required this.onThemeChanged,required this.history,required this.favorites});
  String t(String a,String e)=>arabic?a:e;
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    Text(t('الإعدادات','Settings'),style:const TextStyle(fontSize:29,fontWeight:FontWeight.w900)),const SizedBox(height:18),
    Card(child:Column(children:[
      SwitchListTile(value:dark,onChanged:onThemeChanged,title:Text(t('الوضع الداكن','Dark Mode')),secondary:const Icon(Icons.dark_mode_outlined)),
      const Divider(height:1),
      ListTile(leading:const Icon(Icons.language),title:Text(t('اللغة','Language')),subtitle:Text(arabic?'العربية':'English'),onTap:()=>onLanguageChanged(!arabic)),
    ])),
    const SizedBox(height:12),
    Card(child:Column(children:[
      ListTile(leading:const Icon(Icons.auto_awesome),title:Text(t('نتائج الذكاء الاصطناعي','AI Results')),trailing:const Icon(Icons.chevron_right)),
      const Divider(height:1),
      ListTile(leading:const Icon(Icons.tune),title:Text(t('الفلاتر الافتراضية','Default Filters')),trailing:const Icon(Icons.chevron_right)),
    ])),
    const SizedBox(height:12),
    Card(child:Column(children:[
      ListTile(leading:const Icon(Icons.history),title:Text(t('مسح سجل البحث','Clear History')),trailing:const Icon(Icons.delete_outline)),
      const Divider(height:1),
      ListTile(leading:const Icon(Icons.favorite_border),title:Text(t('مسح المفضلة','Clear Favorites')),trailing:const Icon(Icons.delete_outline)),
    ])),
    const SizedBox(height:22),
    Center(child:Text('Roblox AI Search • v1.0.0',style:const TextStyle(color:Colors.white38))),
  ]);
}
