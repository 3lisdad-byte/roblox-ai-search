# Roblox AI Search

A bilingual (Arabic/English) Flutter MVP for AI-style Roblox game discovery.

## Included
- Arabic RTL / English LTR
- Dark gaming UI with neon gradients
- Home, AI Search, Results, Filters, Game Details, Favorites, History, Settings
- Simulated AI processing flow
- Local favorites/history during the current app session
- "Open in Roblox" deep-link-ready button (MVP placeholder)

## Run
1. Install Flutter.
2. `flutter pub get`
3. `flutter run`

For a production build, connect the `GameRepository` to your backend and Roblox-compatible data source, then connect the AI service server-side. Do not put private API keys in the Android app.
