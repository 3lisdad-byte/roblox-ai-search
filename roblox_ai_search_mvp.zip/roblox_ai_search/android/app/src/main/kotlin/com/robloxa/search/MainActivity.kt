package com.robloxa.search
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
